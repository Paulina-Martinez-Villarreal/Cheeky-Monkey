Main player sprites:
https://www.gameartguppy.com/shop/monkey-game-character-sprites/

Cloud pack:  
https://toppng.com/super-mario-bros-super-mario-bros-cloud-PNG-free-PNG-Images_176526?search-result=mario-cloud

Victory sound effect:
https://freesound.org/people/xtrgamr/sounds/277441/
